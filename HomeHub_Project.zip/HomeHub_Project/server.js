﻿const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

// قاعدة بيانات بسيطة لحفظ الحالة (Persistence)
let db = { homes: {}, users: {} };
if (fs.existsSync('db.json')) db = JSON.parse(fs.readFileSync('db.json'));
const save = () => fs.writeFileSync('db.json', JSON.stringify(db, null, 2));

io.on('connection', (socket) => {
    // 1. نظام الدخول وإنشاء مساحة العمل
    socket.on('joinOrCreate', ({ username, homeCode }) => {
        if (!db.homes[homeCode]) {
            // إنشاء منزل جديد ببيانات افتراضية كما في المتطلبات
            db.homes[homeCode] = {
                devices: [
                    { id: 1, name: 'Main Light', type: 'light', status: 'Off', brightness: 70 },
                    { id: 2, name: 'AC Thermostat', type: 'temp', value: 22 },
                    { id: 3, name: 'Front Door', type: 'lock', status: 'Locked' }
                ],
                logs: [],
                activeUsers: []
            };
        }

        socket.join(homeCode);
        socket.username = username;
        socket.homeCode = homeCode;

        if (!db.homes[homeCode].activeUsers.includes(username)) {
            db.homes[homeCode].activeUsers.push(username);
        }

        save();
        io.to(homeCode).emit('sync', db.homes[homeCode]);
    });

    // 2. التحكم في الأجهزة ومزامنتها لحظياً
    socket.on('action', (data) => {
        const home = db.homes[socket.homeCode];
        const dev = home.devices.find(d => d.id === data.devId);

        if (data.type === 'toggle') dev.status = dev.status === 'On' ? 'Off' : 'On';
        if (data.type === 'dim') dev.brightness = data.val;
        if (data.type === 'temp') dev.value = data.val;
        if (data.type === 'lock') dev.status = dev.status === 'Locked' ? 'Unlocked' : 'Locked';

        // سجل العمليات (Audit Log)
        home.logs.unshift({
            time: new Date().toLocaleTimeString(),
            user: socket.username,
            msg: `Changed ${dev.name} to ${data.val || dev.status}`
        });

        save();
        io.to(socket.homeCode).emit('sync', home);
    });

    socket.on('disconnect', () => {
        // منطق بسيط لإزالة المستخدم من القائمة عند الخروج
    });
});

server.listen(3001, () => console.log('🏠 HomeHub Pro Running on 3001'));